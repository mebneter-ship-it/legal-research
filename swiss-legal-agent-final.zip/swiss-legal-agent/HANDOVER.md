# Swiss Legal Research Agent - Handover Dokument

**Datum:** 1. Januar 2026  
**Status:** Produktionsbereit ✅  
**Getestet:** 4/4 Tests bestanden

---

## 📋 Übersicht

Der Swiss Legal Research Agent ist ein Multi-Agent-System für juristische Recherche im Schweizer Recht. Er durchsucht parallel Bundesrecht, kantonales Recht und Rechtsprechung und liefert strukturierte Analysen mit konkreten Gesetzeszitaten.

### Architektur

```
┌─────────────────────────────────────────────────────────────────┐
│                     SMART ORCHESTRATOR                          │
├─────────────────────────────────────────────────────────────────┤
│  STEP 1: ANALYZE & ENRICH                                       │
│  • Kanton erkennen (AI, ZH, BE, etc.)                          │
│  • Gemeinde erkennen (Appenzell, Zürich, etc.)                 │
│  • Rechtsgebiet erkennen (Baurecht, Mietrecht, etc.)           │
│  • Queries für jeden Agent anreichern                          │
├─────────────────────────────────────────────────────────────────┤
│  STEP 2: PARALLEL SEARCH (gleichzeitig!)                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Primary Law  │  │ Cantonal Law │  │  Case Law    │          │
│  │   (Fedlex)   │  │  (Clex/etc)  │  │   (BGer)     │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
├─────────────────────────────────────────────────────────────────┤
│  STEP 3: ANALYSIS                                               │
│  • Alle Resultate zusammenführen                               │
│  • Strukturierte Antwort generieren                            │
│  • Quellen zitieren                                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 Technische Komponenten

### Dateien

| Datei | Funktion | Zeilen |
|-------|----------|--------|
| `tools.py` | Alle Suchfunktionen, Keyword-Extraktion, Scoring | ~1540 |
| `agents.py` | Smart Orchestrator, LangGraph Pipeline | ~300 |
| `ui.py` | Streamlit Web-Interface | ~950 |
| `main.py` | CLI Entry Point | ~50 |
| `mcp_server.py` | MCP Server für Claude Desktop | ~200 |

### Dependencies

```
langchain>=0.1.0
langchain-openai>=0.0.5
langchain-anthropic>=0.1.0
langgraph>=0.0.20
tavily-python>=0.3.0
streamlit>=1.29.0
python-dotenv>=1.0.0
```

### API Keys (keys.env)

```env
TAVILY_API_KEY=tvly-xxx
OPENAI_API_KEY=sk-xxx        # oder
LLM_PROVIDER=anthropic       # mit ANTHROPIC_API_KEY
```

---

## 🚧 Schwierigkeiten & Lösungen

### 1. Fedlex ist JavaScript-only

**Problem:**  
Die offizielle Bundesrechtsseite `www.fedlex.admin.ch/eli/cc/...` liefert nur:
```
"Bitte JavaScript aktivieren / Veuillez activer JavaScript"
```

Bots und Crawler können keinen Gesetzestext extrahieren.

**Lösung:**  
Drei alternative Quellen priorisieren:

| Priorität | Quelle | Warum |
|-----------|--------|-------|
| 1 | `lawbrary.ch` | HTML mit Gesetzestext + BGE-Links |
| 2 | `fedlex.data.admin.ch` PDFs | Extrahierbarer Text |
| 3 | `admin.ch/seco` | Merkblätter mit Erklärungen |

```python
# Scoring in tools.py
if 'lawbrary.ch' in url:
    score += 35
    matched.append("[LAWBRARY]")
if 'fedlex.data.admin.ch' in url and url.endswith('.pdf'):
    score += 25
    matched.append("[FEDLEX-PDF]")
if 'www.fedlex.admin.ch/eli' in url and not url.endswith('.pdf'):
    score -= 40  # JS-only penalty
    matched.append("[JS-ONLY]")
```

---

### 2. Tavily liefert nur Snippets (500 Zeichen)

**Problem:**  
Standard Tavily-Suche liefert nur kurze Snippets ohne vollständigen Gesetzestext.

**Lösung:**  
`include_raw_content=True` aktivieren:

```python
results = client.search(
    query=query,
    include_raw_content=True,  # ← Volltext!
    search_depth="advanced",
    max_results=10
)
```

Dann Smart Excerpts extrahieren (1500 Zeichen um Keywords):

```python
def extract_relevant_excerpt(raw_content, keywords, context_chars=1500):
    """Extrahiert relevanten Ausschnitt um gefundene Keywords"""
    best_pos = 0
    best_weight = 0
    
    for keyword, weight in keywords:
        pos = content_lower.find(keyword.lower())
        if pos != -1 and weight > best_weight:
            best_pos = pos
            best_weight = weight
    
    start = max(0, best_pos - context_chars // 2)
    end = min(len(raw_content), best_pos + context_chars)
    return f"...{raw_content[start:end]}..."
```

---

### 3. Suchresultate nicht relevant (kommerzielle Seiten oben)

**Problem:**  
Generische Suchanfragen liefern oft kommerzielle Seiten (Anwaltskanzleien, Rechtsportale) statt offizielle Quellen.

**Lösung:**  
Keyword-Extraktion + Domain-basiertes Scoring:

```python
def extract_keywords_from_query(query):
    """Extrahiert gewichtete Keywords"""
    keywords = []
    
    # Art. X → Gewicht 10 (höchste Priorität)
    art_matches = re.findall(r'art\.?\s*(\d+[a-z]?)', query.lower())
    for art in art_matches:
        keywords.append((f"art. {art}", 10))
    
    # Masse (1.5 m, 2m) → Gewicht 8
    measurements = re.findall(r'\d+[.,]?\d*\s*(?:m|cm|meter)', query.lower())
    for m in measurements:
        keywords.append((m, 8))
    
    # Rechtsbegriffe → Gewicht 5
    legal_terms = ['kündigung', 'miete', 'ferien', 'zaun', ...]
    for term in legal_terms:
        if term in query.lower():
            keywords.append((term, 5))
    
    return keywords

def score_search_result(result, keywords, legal_area):
    """Bewertet Suchergebnis nach Relevanz"""
    score = 0
    url = result.get('url', '').lower()
    
    # Domain Trust Bonus
    if 'fedlex.admin.ch' in url: score += 50
    if 'lawbrary.ch' in url: score += 35
    if 'bger.ch' in url: score += 50
    if '.clex.ch' in url: score += 40  # Kantonal
    
    # Keyword Matches
    for keyword, weight in keywords:
        if keyword in content.lower():
            score += weight
    
    # Penalties
    if 'anwalt' in url or 'kanzlei' in url: score -= 20
    if 'javascript' in content and len(content) < 1500: score -= 40
    
    return score
```

---

### 4. Kantonales Recht nicht durchsucht

**Problem:**  
Die ursprüngliche Pipeline suchte nur in Fedlex/BGer, nicht in kantonalen Quellen.

**Lösung:**  
Smart Orchestrator mit Kanton-Erkennung:

```python
# Canton Detection
SWISS_CANTONS = {
    "zürich": "ZH", "zurich": "ZH",
    "bern": "BE", "berne": "BE",
    "appenzell innerrhoden": "AI", "appenzell": "AI",
    # ... alle 26 Kantone
}

def detect_canton(text):
    for name, abbr in SWISS_CANTONS.items():
        pattern = r'\b' + re.escape(name) + r'\b'
        if re.search(pattern, text.lower()):
            return abbr
    return ""
```

Kantonale Rechtssammlungen:

```python
CANTONAL_LAW_URLS = {
    "ZH": "zh.clex.ch",
    "BE": "be.clex.ch", 
    "AI": "ai.clex.ch",
    "GE": "silgeneve.ch",
    # ... etc
}
```

---

### 5. Sequentielle Suche zu langsam

**Problem:**  
Ursprüngliche Pipeline: Primary → Case Law → Analysis (sequentiell = langsam)

**Lösung:**  
Parallele Ausführung mit `concurrent.futures`:

```python
def run_parallel_search(state):
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        future_primary = executor.submit(search_primary)
        future_cantonal = executor.submit(search_cantonal)
        future_case = executor.submit(search_case_law)
        
        # Alle 3 laufen GLEICHZEITIG
        results["primary_law"] = future_primary.result()
        results["cantonal_law"] = future_cantonal.result()
        results["case_law"] = future_case.result()
```

**Vorher:** ~15 Sekunden  
**Nachher:** ~5-7 Sekunden

---

### 6. Analyse-Agent liefert vage Antworten

**Problem:**  
LLM-Antworten waren oft vage ohne konkrete Zahlen oder Zitate.

**Lösung:**  
Strukturierter Analyse-Prompt mit klaren Anweisungen:

```python
ANALYSIS_PROMPT = """Du bist ein Schweizer Rechtsexperte...

WICHTIGE REGELN:
1. Zitiere ALLE Quellen präzise (Art. X Abs. Y Gesetz, BGE X II Y)
2. Unterscheide klar zwischen Bundesrecht und kantonalem Recht
3. Wenn ein Kanton erkannt wurde, priorisiere kantonales Recht
4. Gib konkrete Antworten mit Zahlen/Massen wenn vorhanden
5. Weise auf Unsicherheiten hin

Antworte strukturiert:
1. KURZE ANTWORT (1-2 Sätze mit konkreter Antwort)
2. RECHTSGRUNDLAGE (relevante Artikel mit Zitaten)
3. DETAILS (weitere Informationen)
4. QUELLEN (alle verwendeten Quellen)"""
```

---

### 7. Gemeinde-spezifische Fragen

**Problem:**  
Fragen wie "Zaunhöhe in Appenzell" könnten sich auf die Gemeinde oder den Kanton beziehen.

**Lösung:**  
Gemeinde-Erkennung mit Kanton-Zuordnung:

```python
SWISS_COMMUNES = {
    "appenzell": "AI",
    "zürich": "ZH",
    "basel": "BS",
    "winterthur": "ZH",
    # ... wichtigste Gemeinden
}

def detect_commune(text):
    for name, canton in SWISS_COMMUNES.items():
        if name in text.lower():
            return name.title()
    return ""
```

Wenn Gemeinde erkannt → Gemeinde-Baureglement suchen:

```python
if commune:
    queries.append(f'"{commune}" Baureglement Einfriedung')
```

---

### 8. Konkrete Zahlen gehen in LLM-Zusammenfassung verloren

**Problem:**  
Die Suchfunktion findet "1,50 m" im Gesetzestext, aber die LLM-Agenten (4o-mini) fassen zu abstrakt zusammen:
- Quelle: "Zäune bis zu einer Höhe von 1,50 m"
- Agent-Output: "Die Höhe variiert je nach Gemeinde" ❌

**Lösung:**  
Explizite Anweisungen in allen Prompts (prompts.py):

```python
=== KONKRETE ZAHLEN EXTRAHIEREN (SEHR WICHTIG!) ===
IMMER alle konkreten Zahlen und Masse aus den Quellen übernehmen:
- Höhen: "1,50 m", "1.20 m", "2 Meter" → EXAKT zitieren!
- Abstände: "0,50 m", "3 m Grenzabstand" → EXAKT zitieren!
- Fristen: "30 Tage", "3 Monate" → EXAKT zitieren!

Beispiel aus Quelle: "Zäune dürfen bis zu einer Höhe von 1,50 m erstellt werden"
→ Output: **Art. 30 BauV: Zäune bis 1,50 m Höhe zulässig**

NIEMALS abstrakt formulieren wie "variiert" wenn eine konkrete Zahl in der Quelle steht!
```

Betrifft 3 Prompts:
- `PRIMARY_LAW_SYSTEM_PROMPT`
- `CANTONAL_LAW_SYSTEM_PROMPT`  
- `ANALYSIS_SYSTEM_PROMPT`

---

## ✅ Testergebnisse

### Test 1: Kantonal - Zaunhöhe Appenzell
```
Frage: "Wie hoch darf ein Zaun in Appenzell sein?"
Erkannt: Canton=AI, Commune=Appenzell, Domain=Baurecht
Antwort: 1,50 m gemäss Art. 30 BauV
Quellen: Art. 30 BauV, Merkblatt Einfriedungen
```

### Test 2: Kantonal - Mietrecht Zürich
```
Frage: "Welche Kündigungsfristen gelten für Mietwohnungen in Zürich?"
Erkannt: Canton=ZH, Commune=Zürich, Domain=Mietrecht
Antwort: 3 Monate, Ende März/September
Quellen: Art. 266c OR, BGE 145 III 143
```

### Test 3: Bundesrecht - Arbeitsrecht
```
Frage: "Wie viele Ferientage hat ein Arbeitnehmer in der Schweiz?"
Erkannt: Canton=None, Domain=Arbeitsrecht
Antwort: 4 Wochen (20 Arbeitstage)
Quellen: Art. 329a OR, BGE 128 III 271, SECO FAQ
```

### Test 4: Bundesrecht - Nachbarrecht
```
Frage: "Was sagt Art. 684 ZGB über Immissionen?"
Erkannt: Canton=None, Domain=Nachbarrecht
Antwort: Schutz vor übermässigen Einwirkungen
Quellen: Art. 684 ZGB, 6 BGE-Referenzen
```

---

## 📁 Projektstruktur

```
swiss-legal-agent/
├── agents.py              # Smart Orchestrator + LangGraph
├── tools.py               # Suchfunktionen + Scoring
├── ui.py                  # Streamlit Interface
├── main.py                # CLI Entry Point
├── mcp_server.py          # MCP Server
├── keys.env               # API Keys (nicht committen!)
├── requirements.txt       # Dependencies
├── test_orchestrator.py   # Orchestrator Tests
├── test_primary.py        # Primary Law Tests
├── test_cantonal.py       # Cantonal Law Tests
└── HANDOVER.md            # Dieses Dokument
```

---

## 🚀 Deployment

### Lokal starten

```bash
cd swiss-legal-agent
source venv/bin/activate
streamlit run ui.py
```

### Tests ausführen

```bash
# Alle Tests
python test_orchestrator.py all

# Einzelner Test
python test_orchestrator.py 1  # Appenzell
python test_orchestrator.py 2  # Zürich
python test_orchestrator.py 3  # Ferientage
python test_orchestrator.py 4  # Art. 684
```

---

## 🔮 Mögliche Erweiterungen

| Feature | Beschreibung | Aufwand |
|---------|--------------|---------|
| Weitere Kantone | Alle 26 Kantone mit spezifischen URLs | Mittel |
| PDF-Upload | Verträge hochladen und analysieren | Mittel |
| Chat-History | Konversation mit Follow-up Fragen | Klein |
| Caching | Häufige Anfragen cachen | Klein |
| Französisch/Italienisch | Mehrsprachige Suche | Gross |
| BGE-Volltext | Direkter BGE-Abruf statt Suche | Mittel |

---

## 🔑 Wichtigste Erkenntnisse

### Was funktioniert gut:
1. **lawbrary.ch** - Beste Quelle für Gesetzestext (HTML, nicht JS)
2. **Parallele Suche** - 3x schneller als sequentiell
3. **Domain-Scoring** - Offizielle Quellen zuverlässig oben
4. **Strukturierte Prompts** - Konkrete Antworten mit Zitaten

### Was NICHT funktioniert:
1. **fedlex.admin.ch** - JavaScript-only, für Bots unbrauchbar
2. **Generische Suchen** - Ohne site:-Filter zu viel Rauschen
3. **Ohne raw_content** - Snippets zu kurz für Gesetzestext

### Kritische Code-Stellen:
1. `tools.py:extract_keywords_from_query()` - Keyword-Extraktion
2. `tools.py:score_search_result()` - Relevanz-Scoring
3. `agents.py:run_orchestrator_analyze()` - Query-Anreicherung
4. `agents.py:run_parallel_search()` - Parallele Ausführung
5. `prompts.py:CANTONAL_LAW_SYSTEM_PROMPT` - Zahlen-Extraktion
6. `prompts.py:ANALYSIS_SYSTEM_PROMPT` - Zahlen-Präservierung

---

## 👤 Kontakt

**Entwickler:** Matthias  
**Projekt:** Lokolo Platform / Swiss Legal Agent  
**Stack:** Python, LangGraph, Tavily, OpenAI/Anthropic, Streamlit

---

*Letzte Aktualisierung: 1. Januar 2026*
